const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const root=path.join(__dirname,'..');
const context={window:{}};
vm.runInNewContext(fs.readFileSync(path.join(root,'articles.js'),'utf8'),context);
const articles=context.window.TYPING_ARTICLES;
test('library replaces the former texts with 50 new sourced judgments and 50 labelled adaptations',()=>{
  assert.equal(articles.length,100);
  assert.equal(new Set(articles.map(a=>a.id)).size,100);
  assert.equal(new Set(articles.map(a=>a.text)).size,100);
  for(const kind of ['judgment-original','complaint-adapted'])assert.equal(articles.filter(a=>a.contentKind===kind).length,50);
  for(const a of articles){
    assert.ok(a.id.startsWith('civil-'));
    assert.doesNotMatch(a.text,/[\r\n\u2028\u2029]/,a.id);
    assert.match(a.sources[0].url,/^https:\/\/(ycsfy|rzsfy|hnhxfy)\.hncourt\.gov\.cn\/public\/detail\.php\?id=\d+$/);
    assert.ok(a.caseNumber);
    assert.ok(!a.text.includes('\ufffd'));
    assert.doesNotMatch(a.text,/责任编辑|关闭窗口|All right reserved/);
  }
});
test('judgments remove only line breaks while preserving source snapshots and checksums',()=>{
  for(const a of articles.filter(a=>a.contentKind==='judgment-original')){
    const original=fs.readFileSync(path.join(root,'sources',a.sourceKey+'.txt'),'utf8').replace(/\r\n/g,'\n');
    assert.equal(a.text,original.replace(/[\r\n\u2028\u2029]/g,''),a.id);
    assert.doesNotMatch(a.text,/[\r\n\u2028\u2029]/,a.id);
    assert.equal(crypto.createHash('sha256').update(original).digest('hex'),a.sourceSha256);
    assert.match(a.text,/判决如下[：:]/);
    assert.match(a.text,/书\s*记\s*员/);
  }
});
test('adaptations expose provenance and contain pleading sections without invented filing dates',()=>{
  for(const a of articles.filter(a=>a.contentKind==='complaint-adapted')){
    assert.match(a.title,/起诉状改写/);
    assert.match(a.text,/^民事起诉状（依据公开判决书改写）/);
    for(const section of ['原告','被告','诉讼请求：','事实与理由：','证据和证据来源：','此致','起诉人：'])assert.ok(a.text.includes(section),a.id+section);
    assert.ok(a.text.endsWith('具状日期：未见公开记载'));
    const judgment=articles.find(j=>j.contentKind==='judgment-original'&&j.sourceKey===a.sourceKey);
    assert.equal(a.caseNumber,judgment.caseNumber);
    assert.equal(a.sources[0].url,judgment.sources[0].url);
  }
});


test('the new library excludes every retired article, source and case',()=>{
  const retired=JSON.parse(fs.readFileSync(path.join(root,'sources/retired-library.json'),'utf8'));
  for(const a of articles){
    assert.ok(!retired.articleIds.includes(a.id));
    assert.ok(!retired.caseNumbers.includes(a.caseNumber));
    assert.ok(!retired.sourceUrls.includes(a.sources[0].url));
    assert.ok(!retired.sourceSha256.includes(a.sourceSha256));
  }
  assert.equal(new Set(articles.map(a=>a.caseNumber)).size,50);
  assert.equal(fs.readdirSync(path.join(root,'sources')).filter(x=>x.endsWith('.txt')).length,50);
});

test('adapted requests and facts match reviewed source-grounded records',()=>{
  const cases=JSON.parse(fs.readFileSync(path.join(root,'sources/cases.json'),'utf8'));
  const continuous=s=>s.replace(/[\r\n\u2028\u2029]/g,'');
  for(const c of cases){
    const a=articles.find(a=>a.sourceKey===c.key&&a.contentKind==='complaint-adapted');
    assert.ok(a.text.includes(continuous(c.complaint.request)),c.key);
    assert.ok(a.text.includes(continuous(c.complaint.facts)),c.key);
    assert.ok(a.text.includes(c.court),c.key);
    if(c.complaint.basis.startsWith('诉讼请求、事实与理由摘自')){
      assert.ok(c.text.includes(c.complaint.request),c.key);
      assert.ok(c.text.includes(c.complaint.facts),c.key);
    }
  }
});
