import pathlib, runpy
runpy.run_path(str(pathlib.Path(__file__).with_name("build-library.py")), run_name="__main__")
