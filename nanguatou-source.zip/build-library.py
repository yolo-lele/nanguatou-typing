"""Rebuild the 2026-11-13 library from reviewed court snapshots; no network required."""
import hashlib,json,pathlib,re
ROOT=pathlib.Path(__file__).parent
cases=json.loads((ROOT/'sources/cases.json').read_text(encoding='utf-8'))
retired=json.loads((ROOT/'sources/retired-library.json').read_text(encoding='utf-8'))
continuous=lambda text:re.sub(r'[\r\n\u2028\u2029]','',text)
articles=[]
for case in cases:
    key=case['key']; text=case['text']; complaint=case['complaint']
    assert hashlib.sha256(text.encode()).hexdigest()==case['sha256'],key
    assert (ROOT/'sources'/f'{key}.txt').read_text(encoding='utf-8')==text,key
    assert case['caseNumber'] not in retired['caseNumbers']
    source={'title':case['title']+' · '+case['sourceSite'],'url':case['url']}
    common=dict(language='zh',jurisdiction='中国大陆',caseNumber=case['caseNumber'],sources=[source],collectedAt='2026-11-13',sourceKey=key)
    number=re.search(r'民初(\d+)号',case['caseNumber'])[1]
    title=case['topic']+'（'+number+'号）'
    note='法院官网公开判决文本，保留公开文本及匿名方式；练习文本仅去除段落换行，其余文字和标点保留，不按字数裁剪。源码保留带段落的来源快照及校验值。历史法律引用、原网站笔误及各方不同主张按来源保留。'
    if key.startswith('hnhxfy-') and key!='hnhxfy-2917':
        note+='本篇为滑县法院网转载的公开版本，含原页面的案件信息、栏目标题；审理法院为'+case['court']+'。'
    if key=='hnhxfy-2917':note+='本篇完整提取来源页面“附：案例相关裁判文书”，前置案例评析不作为判决书正文。'
    articles.append(dict(**common,id='civil-judgment-'+key,title=title+'｜民事判决书原文',category='民事判决书',difficulty='原文',description=case['caseNumber']+' · 法院公开文本',text=continuous(text),sourceSha256=case['sha256'],contentKind='judgment-original',sourceNote=note))
    pleading='\n'.join(['民事起诉状（依据公开判决书改写）',*complaint['parties'],'诉讼请求：',complaint['request'],'事实与理由：',complaint['facts'],'证据和证据来源：',complaint['evidence'],'此致',case['court'],'起诉人：'+'、'.join(complaint['plaintiffs']),'具状日期：未见公开记载'])
    articles.append(dict(**common,id='civil-complaint-'+key,title=title+'｜民事起诉状改写',category='民事起诉状',difficulty='改写',description=case['caseNumber']+' · 依据真实案件改写',text=continuous(pleading),contentKind='complaint-adapted',sourceNote='依据所链接真实案件整理的速录练习稿，并非当事人提交的起诉状原件。'+complaint['basis']+'证据部分仅列公开判决记载的材料，不补造证据份数、未公开日期或签名；练习文本去除全部换行。'))
assert len(cases)==50 and len(articles)==100
assert len({a['id'] for a in articles})==len({a['text'] for a in articles})==100
assert not ({a['id'] for a in articles}&set(retired['articleIds']))
(ROOT/'articles.js').write_text('// 50 new public judgments and 50 explicitly labelled adapted complaints.\nwindow.TYPING_ARTICLES = '+json.dumps(articles,ensure_ascii=False,indent=2)+';\n',encoding='utf-8')
(ROOT/'legal-sources.json').write_text(json.dumps({'collectedAt':'2026-11-13','note':'旧题库50篇全部下架；本版50篇新判决与50篇对应起诉状改写稿。','cases':[{k:v for k,v in c.items() if k not in ('text','complaint')} for c in cases]},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'articles':len(articles),'judgments':len(cases),'adaptations':len(cases),'minChars':min(len(a['text']) for a in articles),'maxChars':max(len(a['text']) for a in articles)},ensure_ascii=False))
